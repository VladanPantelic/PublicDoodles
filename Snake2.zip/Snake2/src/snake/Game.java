package snake;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;

public final class Game extends JPanel implements Runnable {
    public static Game me;
    
    public static final int WIDTH=800, HEIGHT=500; //Window size igrice(samo celi brojevi pixela)
    private static Thread thread;
    private static boolean running = false; //stanje igrice
    
    private static BodyPart b;
    private static ArrayList<BodyPart> snake; //zmijica je segmentovana pa je pravimo preko arrayliste
    
    private static Apple apple;
    private static ArrayList<Apple> apples;                // jabuke po istom principu
    private static Random r;                   // koristimo random funkciju za generaciju lokacije jabuka
    private static Font font;
    private static int xCoor = WIDTH/20 , yCoor = HEIGHT/20; //inicijalizacija koordinata
    private static int size=6;                 //velicina zmijice
    
    private static boolean right = true, left = false, up = false, down = false; // u kom smeru se krece zmijica (inicijalizacija)

    private static int ticks = 0;                      //inicijalizacija tikova
    
    private static Key key;                        //inicijalizacija key(tastature)
    
    public static void reset() {
        snake  = new ArrayList< BodyPart >();             //stvaranje liste delova zmije i jabuka ispod
        apples = new ArrayList< Apple >(); 
        r = new Random();               // random za pozicije jabuka
        xCoor = WIDTH/20;
        yCoor = HEIGHT/20;
        size = 6;
        start(); 
    }
    
    public Game() {
        me = this;

        setFocusable(true);
        key = new Key();
        addKeyListener(key);
        
        setPreferredSize(new Dimension(WIDTH, HEIGHT));     //velicina windowa(dimenzije)
        
        reset();
    }
    public void tick(){              //funkcija za protok vremena - tikovanje
        
        if(snake.size() == 0){  //stvaranje zmije
            b = new BodyPart(xCoor, yCoor, 10);
            snake.add(b);
        }
        
        if( apples.size() == 0){    //stvaranje jabuka
            int xCoor = r.nextInt(WIDTH/10 - 1);
            int yCoor = r.nextInt((HEIGHT/10 - 1));
            if(yCoor<3)yCoor=3;
            
            apple = new Apple(xCoor, yCoor, 10);
            apples.add(apple);
        }
        
        for(int i = 0; i < apples.size(); i++){  //brisanje jabuka
            if(xCoor == apples.get(i).getxCoor() && yCoor == apples.get(i).getyCoor()){
                size++;
                apples.remove(i);
                i--;
            }
        }
        
        for(int i =0; i < snake.size(); i++){ //zaustavljanje ako se zmijica sudari sama sa sobom
            if(xCoor == snake.get(i).getxCoor() && yCoor == snake.get(i).getyCoor()){
                if(i != snake.size() -1){
                    stop();
                }
            }
        }   
        
        if(xCoor<0 || xCoor>(WIDTH/10 - 1) || yCoor==1 || yCoor>(HEIGHT/10 - 1)){
            stop();                            // zaustavljanje ako se sudari sa zidovima windowa
        }
        
        ticks++;
        
        if(ticks>400000){      //brzina kretanja zmijice i fukncija brisanje poslednjeg segmenta
            if(right)xCoor++;
            if(left)xCoor--;
            if(up)yCoor--;
            if(down)yCoor++;
        
            ticks = 0;

            b = new BodyPart(xCoor, yCoor, 10);
            snake.add(b);

            if(snake.size() > size) {
                snake.remove(0);
            }
        }
    }
    
    @Override
    public void paint(Graphics g) { //boja pozadine, zmije, jabuke
        
        g.setColor(Color.BLACK);  //pozadina
        for(int i=0; i< WIDTH/10;i++) {
            g.fillRect(i*10, 0, i*10, HEIGHT);
        }
        for(int i=0; i< HEIGHT/10; i++) {
            g.fillRect(0, i*10, WIDTH, i*10);
        }
        g.fillRect(0, 0, WIDTH, HEIGHT);
        
        
        g.setColor(Color.DARK_GRAY); //grid 
        for(int i=0; i< WIDTH/10;i++) {
            g.drawLine(i*10, 0, i*10, HEIGHT);
        }
        for(int i=0; i< HEIGHT/10; i++) {
            g.drawLine(0, i*10, WIDTH, i*10);
        }
                
        g.setColor(Color.DARK_GRAY);
        g.fillRect( 0, 0, WIDTH , 20);
        
        for(int i=0; i<snake.size(); i++){ //zmijica
            snake.get(i).draw(g);
        }
        
        for(int i = 0; i < apples.size(); i++){  //jabuka
            apples.get(i).draw(g);  
        }
        
        g.setColor(Color.RED);
        g.drawString("Duzina zmije je: " + size,350,10);
        
        g.setColor(Color.RED);
        g.drawString("Pojeli ste: " + (size-6) +" jabuka.",350,20);
        
        if(running==false){             //game over screen
                g.setColor(Color.RED);
            for(int i=0; i< WIDTH/10;i++) {
                g.fillRect(i*10, 0, i*10, HEIGHT);
            }
            for(int i=0; i< HEIGHT/10; i++) {
                g.fillRect(0, i*10, WIDTH, i*10);
            }
            g.fillRect(0, 0, WIDTH, HEIGHT);
            g.setColor(Color.BLACK);
            g.setFont(new Font("sans serif", font.BOLD, 30));
            g.drawString("GAME OVER", 300, 200);
            g.setFont(new Font("serif", font.BOLD, 15));
            g.drawString("Score: " + (size-6), 365, 250);
            g.setFont(new Font("sans serif", font.PLAIN, 12));
            g.drawString("R to Restart", 360, 280);
        }
    }
    
    public static void start(){ //poctak programa
        running = true;
        thread = new Thread(me, "Game Loop");
        thread.start();
    }

    public void stop(){                 //kraj programa
        running = false;
        try {
            thread.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public void run(){                   //trajanje programa
        while(running){
            tick();
            repaint();
        }
    }
    
    private class Key implements KeyListener { //kretanje zmijice preko strelica na tastaturi

        @Override
        public void keyPressed(KeyEvent e) {
            int key = e.getKeyCode();

            if(key == KeyEvent.VK_RIGHT && !left){
                up=false;
                down=false;
                right=true;
            }
            
            if(key == KeyEvent.VK_LEFT && !right){
                up=false;
                down=false;
                left=true;
            }
            
            if(key == KeyEvent.VK_UP && !down){
                up=true;
                left=false;
                right=false;
            }
            
            if(key == KeyEvent.VK_DOWN && !up){ 
                left=false;
                down=true;
                right=false;
            }

            if(key == KeyEvent.VK_R && !running){
                running = true;
                reset();
            }
        }
        
        @Override
        public void keyTyped(KeyEvent e) { }
        @Override
        public void keyReleased(KeyEvent e) { }
    }
}