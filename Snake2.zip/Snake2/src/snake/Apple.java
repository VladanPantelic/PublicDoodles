package snake;

import java.awt.Color;
import java.awt.Graphics;

public class Apple {
    
    private int xCoor, yCoor, width, height;
    
    public Apple(int xCoor, int yCoor, int tileSize){ //velicina jabuke
        this.xCoor=xCoor;
        this.yCoor=yCoor;
        width=tileSize;
        height=tileSize;
    }
    public void tick(){ }
    
    public void draw(Graphics g){ //bojenje jabuke
        g.setColor(Color.red);
        g.fillRect(xCoor*width, yCoor*height, width+1, height+1);
    }
    //geteri i seteri
    public int getxCoor() {
        return xCoor;
    }

    public void setxCoor(int xCoor) {
        this.xCoor = xCoor;
    }

    public int getyCoor() {
        return yCoor;
    }

    public void setyCoor(int yCoor) {
        this.yCoor = yCoor;
    }
    
}
