package snake;

import java.awt.GridLayout;

import javax.swing.JFrame;

public class Frame extends JFrame {
 
    public Frame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //gasenje programa po zatvaranju prozora
        setTitle("Snake"); //naslov prozora
        setResizable(false); //staticna velicina prozora
        
        init(); //inicijalizacija
    }
    
    public void init() {
        setLayout(new GridLayout(1,1,0,0)); //postavljanje grida
            
        Game s = new Game(); //pocetak
        add(s);
        
        pack(); //funkcija
        
        setLocationRelativeTo(null); //centriran prozor
        setVisible(true); //vidan
    }
    
    public static void main(String[] args) { // main
        new Frame();
    }
}